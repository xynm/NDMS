
int main (int argc, char** argv);
char** parseArgs(int argc, char**argv);
int end();
