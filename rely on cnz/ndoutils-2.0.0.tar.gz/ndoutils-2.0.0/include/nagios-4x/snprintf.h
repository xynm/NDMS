/* include/snprintf.h.  Generated from snprintf.h.in by configure.  */
/* -*- C -*- */
/* #undef HAVE_SNPRINTF */
/* #undef NEED_VA_LIST */
